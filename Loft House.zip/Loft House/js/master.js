const navBtn = document.querySelector('.nav__icon-btn')
const iconBtn = document.querySelector('.nav__icon-btn')
const topRow = document.querySelector('.header__top-row')



navBtn.onclick = function(){
    iconBtn.classList.toggle('nav__icon-btn-big')
    topRow.classList.toggle('header__top-row--mobile')
    
}

mask('[data-tel-input]')
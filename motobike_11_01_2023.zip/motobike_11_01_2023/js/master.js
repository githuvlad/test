$(function(){
    $('.bike-slider, .slider__items').slick({
        arrows:false,
        dots:true,
        fade:true,
        autoplay: true,
        autoplaySpeed: 2000
      });
})